/*
* wyshell.c
* Author: Buck Harris
* Date: April 1, 2023
*
* COSC 3750, Homework 10
*
* This is the code for the wyshell
* program that emulates the shell
* command.
*/

#include "wyscanner.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/wait.h>


typedef struct node Node;
struct node
{
 struct node *next,*prev;
 char **argv;
 int argc;
 int input, output, error;
 char *in_file, *out_file, *err_file;
};


Node* createNode()
{
 Node *myNode = calloc(1,sizeof(Node));
 if(myNode == NULL)
 {
  perror("calloc()");
  return NULL;
 }
 myNode->argc = 0;
 myNode->argv = calloc(50, sizeof(char*));
 if(myNode->argv == NULL)
 {
  perror("calloc()");
  return NULL;
 }
 myNode->input = STDIN_FILENO;
 myNode->output = STDOUT_FILENO;
 myNode->error = STDERR_FILENO;
 myNode->in_file = "stdin";
 myNode->out_file = "stdout";
 myNode->err_file = "stderr";

 return myNode;
}

void execute_commands(Node *head, int amp)
{
 if (head->argc == 0)
 {
  return;
 }

 Node *curr = head;
 int pIndex = 0;
 int childPids[50];
 int pipeFD[2];
 int previousReadFD = -1;

 while (curr != NULL)
 {
  if (curr->next != NULL)
  {
   if (pipe(pipeFD) == -1)
   {
    perror("pipe");
    exit(1);
   }
  }

  childPids[pIndex] = fork();
  if (childPids[pIndex] == -1)
  {
   perror("fork");
   exit(1);
  }
  else if (childPids[pIndex] == 0)
  {
   if (previousReadFD != -1)
   {
    dup2(previousReadFD, STDIN_FILENO);
    close(previousReadFD);
   }
   else if (curr->input != STDIN_FILENO)
   {
    int fdIn = open(curr->in_file, O_RDONLY);
    if (fdIn == -1)
    {
     perror(curr->in_file);
     exit(1);
    }
     dup2(fdIn, STDIN_FILENO);
     close(fdIn);
    }

    if (curr->error != STDERR_FILENO)
    {
     int fdErr;
     if (curr->error == REDIR_ERR)
     {
      fdErr = open(curr->err_file, O_WRONLY | O_CREAT | O_TRUNC, 00600);
     }
     else if (curr->error == APPEND_ERR)
     {
      fdErr = open(curr->err_file, O_WRONLY | O_CREAT | O_APPEND, 00600);
     }
     else if (curr->error == REDIR_ERR_OUT)
     {
      if (strcmp(curr->err_file, "stdout") == 0)
      {
       fdErr = STDOUT_FILENO;
      }
      else
      {
       fdErr = open(curr->err_file, O_WRONLY | O_CREAT | O_TRUNC, 00600);
      }
     }
     if (fdErr == -1)
     {
      perror(curr->err_file);
      exit(1);
     }
     dup2(fdErr, STDERR_FILENO);
     if (fdErr != STDOUT_FILENO)
     {
      close(fdErr);
     }
    }

    if (curr->next != NULL)
    {
     dup2(pipeFD[1], STDOUT_FILENO);
     close(pipeFD[0]);
     close(pipeFD[1]);
    }
    else if (curr->output != STDOUT_FILENO)
    {
     int fdOut;
     if (curr->output == REDIR_OUT)
     {
      fdOut = open(curr->out_file, O_WRONLY | O_CREAT | O_TRUNC, 00600);
     }
     else if (curr->output == APPEND_OUT)
     {
      fdOut = open(curr->out_file, O_WRONLY | O_CREAT | O_APPEND, 00600);
     }
     if (fdOut == -1)
     {
      perror(curr->out_file);
      exit(1);
     }
      dup2(fdOut, STDOUT_FILENO);
      close(fdOut);
     }

     execvp(curr->argv[0], curr->argv);
     perror(curr->argv[0]);
     exit(1);
    }
    else
    {
     if (previousReadFD != -1)
     {
      close(previousReadFD);
     }
     if (curr->next != NULL)
     {
      close(pipeFD[1]);
      previousReadFD = pipeFD[0];
     }
     curr = curr->next;
     pIndex++;
    }
   }

   if (!amp)
   {
    for (int i = 0; i < pIndex; i++)
    {
     int status;
     waitpid(childPids[i], &status, 0);
    }
  }
}





void killZombies()
{
 int status;
 pid_t pid;
 // Wait for child termination
 while ((pid = waitpid(-1, &status, WNOHANG)) > 0)
 {
  //killing those dirty stinky zombies
 }
}

void deallocate(Node *head)
{
 Node *current;
 while(head != NULL)
 {
  current = head;
  head = head->next;
  for(int i = 0; i < current->argc; i++)
  {
   free(current->argv[i]);
  }
  free(current->argv);
  free(current);
 }
}

int main(int argc, char** argv)
{
 while(1)
 {
  Node *head = NULL;
  Node *current = NULL;
  int rtn;
  char *rpt;
  char buf[1024];

  int break_flag = 0;

  //get line of input
  fprintf(stdout,"$> ");
  rpt=fgets(buf,256,stdin);
  if(rpt == NULL)
  {
   if(feof(stdin))
   {
    killZombies();
    return 0;
   }
   else
   {
    perror("fgets from stdin");
    return 1;
   }
  }

  //create head node
  if(head == NULL)
  {
   head = createNode();
   if(head == NULL)
   {
    return 1;
   }
   current = head;
  }

  //begin parsing line
  rtn = parse_line(buf);
  while(1)
  {
   switch(rtn)
   {
    case QUOTE_ERROR:
     fprintf(stderr,"QUOTE_ERROR\n");
     break_flag++;
     break;
    case ERROR_CHAR:
     fprintf(stderr,"ERROR_CHAR: %c\n", error_char);
     break_flag++;
     break;
    case SYSTEM_ERROR:
     perror("system error");
     exit(1);
     break;
    case EOL:
     if(current->input == PIPE && current->argc == 0)
     {
      fprintf(stderr, "Error: cannot end command with pipe.\n");
      break_flag++;
      break;
     }
     //fprintf(stdout," --: EOL\n");
     break_flag++;
     execute_commands(head, 0);
     break;
    case REDIR_OUT:
     if(current->argc == 0)
     {
      fprintf(stderr, "Error: Must specify command before redirect.\n");
      break_flag++;
      break;
     }
     if(current->output != STDOUT_FILENO)
     {
      break_flag++;
      fprintf(stderr, "Error: too many output redirections.\n");
      break;
     }
     current->output = REDIR_OUT;
     //fprintf(stdout," >\n");
     rtn = parse_line(NULL);
     if(rtn == WORD)
     {
      current->out_file = strdup(lexeme);
      //printf(" --: %s\n", current->out_file);
     }
     else
     {
      fprintf(stderr, "Error: Invalid  arguments.\n");
      break_flag++;
     }
     break;
    case REDIR_IN:
     if(current->argc == 0)
     {
      fprintf(stderr, "Error: Must specify command before redirect.\n");
      break_flag++;
      break;
     }
     if(current->input == PIPE)
     {
      fprintf(stderr, "Error: Cannot redirect input after pipe.\n");
      break_flag++;
      break;
     }
     if(current->input != STDIN_FILENO)
     {
      break_flag++;
      fprintf(stderr, "Error: too many input redirections.\n");
      break;
     }
     current->input = REDIR_IN;
     //fprintf(stdout," <\n");
     rtn = parse_line(NULL);
     if(rtn == WORD)
     {
      current->in_file = strdup(lexeme);
      //printf(" --: %s\n", current->in_file);
     }
     else
     {
      fprintf(stderr, "Error: Invalid  arguments.\n");
      break_flag++;
     }
     break;
    case REDIR_ERR:
     if(current->argc == 0)
     {
      fprintf(stderr, "Error: Must specify command before redirect.\n");
      break_flag++;
      break;
     }
     if(current->error != STDERR_FILENO)
     {
      break_flag++;
      fprintf(stderr, "Error: too many error redirections.\n");
      break;
     }
     current->error = REDIR_ERR;
     //fprintf(stdout," 2>\n");
     rtn = parse_line(NULL);
     if(rtn == WORD)
     {
      current->err_file = strdup(lexeme);
      //printf(" --: %s\n", current->err_file);
     }
     else
     {
      fprintf(stderr, "Error: Invalid  arguments.\n");
      break_flag++;
     }
     break;
    case APPEND_OUT:
     if(current->argc == 0)
     {
      fprintf(stderr, "Error: Must specify command before redirect.\n");
      break_flag++;
      break;
     }
     if(current->output != STDOUT_FILENO)
     {
      break_flag++;
      fprintf(stderr, "Error: too many output redirections.\n");
      break;
     }
     current->output = APPEND_OUT;
     rtn = parse_line(NULL);
     if(rtn == WORD)
     {
      current->out_file = strdup(lexeme);
      //printf(" --: %s\n", current->out_file);
     }
     else
     {
      fprintf(stderr, "Error: Invalid  arguments.\n");
      break_flag++;
     }
     fprintf(stdout," >>\n");
     break;
    case APPEND_ERR:
     if(current->argc == 0)
     {
      fprintf(stderr, "Error: Must specify command before redirect.\n");
      break_flag++;
      break;
     }
     if(current->error != STDERR_FILENO)
     {
      break_flag++;
      fprintf(stderr, "Error: too many error redirections.\n");
      break;
     }
     current->error = APPEND_ERR;
     //fprintf(stdout," 2>>\n");
     rtn = parse_line(NULL);
     if(rtn == WORD)
     {
      current->err_file = strdup(lexeme);
      //printf(" --: %s\n", current->err_file);
     }
     else
     {
      fprintf(stderr, "Error: Invalid  arguments.\n");
      break_flag++;
     }
     break;
    case REDIR_ERR_OUT:
     if(current->argc == 0)
     {
      fprintf(stderr, "Error: Must specify command before redirect.\n");
      break_flag++;
      break;
     }
     if(current->error != STDERR_FILENO)
     {
      break_flag++;
      fprintf(stderr, "Error: too many error redirections.\n");
      break;
     }
     current->error = REDIR_ERR_OUT;
     current->err_file = strdup(current->out_file);
     //fprintf(stdout," 2>&1\n");
     break;
    case SEMICOLON:
     if(current->input == PIPE && current->argc == 0)
     {
      fprintf(stderr, "Error: cannot end command with pipe.\n");
      break_flag++;
      break;
     }
     //fprintf(stdout, " ;\n");
     execute_commands(head, 0);
     deallocate(head);
     head = NULL;
     current = NULL;
     //create new head
     if(head == NULL)
     {
      head = createNode();
      if(head == NULL)
      {
       return 1;
      }
      current = head;
     }
     break_flag = 0;
     break;
    case PIPE:
     if(current->argc == 0)
     {
      fprintf(stderr, "Error: Must specify command before pipe.\n");
      break_flag++;
      break;
     }
     if(current->output == REDIR_OUT)
     {
      fprintf(stderr, "Error: Cannot redirect output before pipe.\n");
      break_flag++;
      break;
     }
     if(current->input == PIPE && current->argc == 0)
     {
      fprintf(stderr, "Error: too many pipes.\n");
      break_flag++;
      break;
     }
     //fprintf(stdout, " |\n");
     current->output = PIPE;
     current->next = createNode();
     current = current->next;
     current->input = PIPE;
     break;
    case AMP:
     if(current->argc == 0)
     {
      fprintf(stderr, "Error: Must specify command before &.\n");
      break_flag++;
      break;
     }
     //fprintf(stdout, " &\n");
     rtn = parse_line(NULL);
     if(rtn == EOL)
     {
      if(current->input == PIPE && current->argc == 0)
      {
       fprintf(stderr, "Error: cannot end command with pipe.\n");
       break_flag++;
       break;
      }
      //fprintf(stdout," --: EOL\n");
      break_flag++;
      execute_commands(head, 1);
      break;
     }
     else if(rtn == SEMICOLON)
     {
      if(current->input == PIPE && current->argc == 0)
      {
       fprintf(stderr, "Error: cannot end command with pipe.\n");
       break_flag++;
       break;
      }
      //fprintf(stdout, " ;\n");
      execute_commands(head, 1);
      deallocate(head);
      head = NULL;
      current = NULL;
      //create new head
      if(head == NULL)
      {
       head = createNode();
       if(head == NULL)
       {
        return 1;
       }
       current = head;
      }
      break_flag = 0;
      break;
     }
     else
     {
      fprintf(stderr,"Ampersand must be at end of command.\n");
      break_flag++;
      break;
     }
     case WORD:
      if(current->argc == 0)
      {
       current->argv[current->argc] = strdup(lexeme);
       current->argc++;
       //printf(":--: %s\n", current->argv[argc]);
      }
      else if(current->output != REDIR_OUT &&
                  current->input != REDIR_IN &&
                   current->error != REDIR_ERR)
      {
       current->argv[current->argc] = strdup(lexeme);
       current->argc++;
       //printf(" --: %s\n", current->argv[argc]);
      }
      else
      {
       fprintf(stderr, "Error: Invalid  arguments.\n");
       break_flag++;
      }
      break;
     default:
      fprintf(stdout,"Unknown token: %d\n", rtn);
    }
    //check things that cause us to abandon line
    if(break_flag > 0)
    {
     break;
    }
    rtn = parse_line(NULL);
    int status;
    while(waitpid(-1, &status, WNOHANG)>0)
    {}
   }
   deallocate(head);
  }
}







